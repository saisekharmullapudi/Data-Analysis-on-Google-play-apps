From the provided dataset, select any app for which you want to get recommendations.
Run the Recommendation.py file.
Input the name of the app upon prompt exactly as shown in the datafile.
Input the number of recommendations required. 